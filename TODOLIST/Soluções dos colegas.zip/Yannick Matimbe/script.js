alert('✔ - marca como tarefa feita \n❌ - marca como tarefa não feita'
)

window.onload = function() {
    carregarTarefas();
};

function novaTarefa(event) {
    event.preventDefault();

    const inputField = document.getElementById('input-field');
    const taskDescription = inputField.value.trim();

    if (taskDescription !== "") {
        adicionarTarefaNaLista(taskDescription);
        salvarTarefas();
        inputField.value = '';
    }
}

function adicionarTarefaNaLista(taskDescription) {
    const taskList = document.getElementById('task-list');

    const newTask = document.createElement('li');
    newTask.innerHTML = `
        <div id = 'task'>
            <p id = 'task-desc'>${taskDescription}</p>
            <button id = 'edit' onclick="marcarComoConcluida(this)">✔</button>
            <button style="background-color:red;" onclick="deletarTarefa(this)">Delete</button>
        </div>
    `;

    taskList.appendChild(newTask);
}

function marcarComoConcluida(button) {
    if(button.parentElement.querySelector('p').style.textDecoration===''){
        button.parentElement.querySelector('p').style.textDecoration = 'line-through'
        button.parentElement.querySelector('p').style.color = 'red'
        button.textContent = '❌'
    }else{
        button.parentElement.querySelector('p').style.textDecoration = '';
        button.parentElement.querySelector('p').style.color = 'black'
        button.textContent = '✔'
    } 
    salvarTarefas();
}


function deletarTarefa(button) {
    const confirmacao = confirm("Tem certeza de que deseja deletar esta tarefa?");
    
    if (confirmacao) {
        button.parentElement.parentElement.remove();
        salvarTarefas();
    }
}


function salvarTarefas() {
    const taskList = document.getElementById('task-list');
    const tasks = [];

    taskList.querySelectorAll('li').forEach(task => {
        const description = task.querySelector('p').textContent;
        const isCompleted = task.querySelector('p').style.textDecoration === 'line-through';
        tasks.push({ description, isCompleted });
    });

    localStorage.setItem('tarefas', JSON.stringify(tasks));
}

function carregarTarefas() {
    const tasks = JSON.parse(localStorage.getItem('tarefas'));

    if (tasks) {
        tasks.forEach(task => {
            adicionarTarefaNaLista(task.description);

            if (task.isCompleted) {
                document.querySelector('#task-list li:last-child p').style.textDecoration = 'line-through';
                document.querySelector('#task-list li:last-child p').style.color = 'red';
                document.querySelector('#task-list li:last-child button').textContent = '❌';
            }
        });
    }
}


function limparTodasTarefas() {
    document.getElementById('task-list').innerHTML = ''; 
    localStorage.removeItem('tarefas');
}
