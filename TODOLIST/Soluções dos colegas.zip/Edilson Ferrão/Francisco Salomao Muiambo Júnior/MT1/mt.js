const novaTarefaInput = document.getElementById('nova-tarefa');
const listaTarefas = document.getElementById('lista-tarefas');
const adicionarTarefaBtn = document.getElementById('adicionar-tarefa');

function carregarTarefas() {
    const tarefasSalvas = JSON.parse(localStorage.getItem('tarefas')) || [];
    tarefasSalvas.forEach(tarefa => {
        adicionarTarefa(tarefa.texto, tarefa.feito);
    });
}

function salvarTarefas() {
    const tarefas = [];
    listaTarefas.querySelectorAll('li').forEach(item => {
        tarefas.push({ texto: item.querySelector('span').innerText, feito: item.classList.contains('feito') });
    });
    localStorage.setItem('tarefas', JSON.stringify(tarefas));
}

function adicionarTarefa(texto, feito = false) {
    const li = document.createElement('li');
    const span = document.createElement('span');
    span.innerText = texto;

    const botaoFeito = document.createElement('button');
    botaoFeito.innerText = 'Feito';
    botaoFeito.onclick = () => {
        li.classList.toggle('feito');
        salvarTarefas();
    };

    const botaoRemover = document.createElement('button');
    botaoRemover.innerText = 'Remover';
    botaoRemover.onclick = () => {
        li.remove();
        salvarTarefas();
    };

    li.appendChild(span);
    li.appendChild(botaoFeito);
    li.appendChild(botaoRemover);

    if (feito) li.classList.add('feito');
    listaTarefas.appendChild(li);
    salvarTarefas();
}

adicionarTarefaBtn.onclick = () => {
    if (novaTarefaInput.value.trim()) {
        adicionarTarefa(novaTarefaInput.value.trim());
        novaTarefaInput.value = '';
    }
};

carregarTarefas();

