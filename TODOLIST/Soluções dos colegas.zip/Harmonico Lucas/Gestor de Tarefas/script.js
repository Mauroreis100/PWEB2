const entradaTarefa = document.getElementById("entradaTarefa");
const btnAdicionarTarefa = document.getElementById("btnAdicionarTarefa");
const listaTarefas = document.getElementById("listaTarefas");


document.addEventListener("DOMContentLoaded", carregarTarefasDoLocalStorage);


function adicionarTarefa() {
    const textoTarefa = entradaTarefa.value.trim();
    if (textoTarefa === "") return;

    const tarefa = {
        texto: textoTarefa,
        concluida: false
    };

    adicionarTarefaAoDOM(tarefa);
    salvarTarefaNoLocalStorage(tarefa);

    entradaTarefa.value = "";
}


function adicionarTarefaAoDOM(tarefa) {
    const li = document.createElement("li");

    
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = tarefa.concluida;


    checkbox.addEventListener("change", function() {
        tarefa.concluida = checkbox.checked;
        li.classList.toggle("completed", tarefa.concluida);
        atualizarTarefaNoLocalStorage(tarefa);
    });

    li.appendChild(checkbox);

    const spanTexto = document.createElement("span");
    spanTexto.textContent = tarefa.texto;
    li.appendChild(spanTexto);

   
    if (tarefa.concluida) {
        li.classList.add("completed");
    }


    const btnApagar = document.createElement("button");
    btnApagar.textContent = "Apagar";
    btnApagar.addEventListener("click", function() {
        listaTarefas.removeChild(li);
        removerTarefaDoLocalStorage(tarefa.texto);
    });

    li.appendChild(btnApagar);
    listaTarefas.appendChild(li);
}


function salvarTarefaNoLocalStorage(tarefa) {
    let tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];
    tarefas.push(tarefa);
    localStorage.setItem("tarefas", JSON.stringify(tarefas));
}

function removerTarefaDoLocalStorage(textoTarefa) {
    let tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];
    tarefas = tarefas.filter(tarefa => tarefa.texto !== textoTarefa);
    localStorage.setItem("tarefas", JSON.stringify(tarefas));
}


function atualizarTarefaNoLocalStorage(tarefaAtualizada) {
    let tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];
    tarefas = tarefas.map(tarefa => tarefa.texto === tarefaAtualizada.texto ? tarefaAtualizada : tarefa);
    localStorage.setItem("tarefas", JSON.stringify(tarefas));
}


function carregarTarefasDoLocalStorage() {
    let tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];
    tarefas.forEach(tarefa => {
        adicionarTarefaAoDOM(tarefa);
    });
}


btnAdicionarTarefa.addEventListener("click", adicionarTarefa);


entradaTarefa.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
        adicionarTarefa();
    }
});
