let button = document.querySelector(".create-button");

console.log(button);

button.addEventListener("click", () => {
    let input = document.querySelector(".new-task-input");
    let task = `
        <div class="task">
            <div class="left-container">
                <input type="checkbox" class="checkbox">
                <span class="task-text">${input.value}</span>
            </div>
            <div class="right-container">
                <span class="fa fa-trash"></span>
            </div>
        </div>
    `;
    let tasksContainer = document.querySelector(".cards");
    tasksContainer.innerHTML += task;

    
    let trashIcons = document.querySelectorAll(".fa-trash");
    trashIcons.forEach(icon => {
        icon.addEventListener("click", () => {
            icon.closest('.task').remove();
        });
    });
});
