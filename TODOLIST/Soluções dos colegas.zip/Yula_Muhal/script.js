// Yula Muhal Lecc 31
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('myModal');
    const adicionarTarefa = document.getElementById('adicionarTarefa');
    const closeModalSpan = document.querySelector('.close');
    const btnAdicionar = document.getElementById('btnAdicionar');
    const lista = document.getElementById('lista');
    const descTarefa = document.getElementById('descTarefa');

    function loadTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        lista.innerHTML = '';
        tasks.forEach(task => addTaskToList(task.text, task.completed));
    }

    function saveTasks() {
        const tasks = Array.from(lista.children).map(item => ({
            text: item.querySelector('label').textContent,
            completed: item.querySelector('input').checked
        }));
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function addTaskToList(taskText, completed = false) {
        const listItem = document.createElement('li');

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = completed;
        checkbox.onclick = function() {
            listItem.classList.toggle('completed', checkbox.checked);
            saveTasks();
        };

        const label = document.createElement('label');
        label.textContent = taskText;

        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remover';
        removeBtn.style.backgroundColor = 'red';
        removeBtn.onclick = function() {
            listItem.remove();
            saveTasks();

            
        };

        listItem.appendChild(checkbox);
        listItem.appendChild(label);
        listItem.appendChild(removeBtn);
        lista.appendChild(listItem);
    }

    adicionarTarefa.onclick = function() {
        modal.style.display = 'block';
    }

    closeModalSpan.onclick = function() {
        modal.style.display = 'none';
    }

    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    }

    btnAdicionar.onclick = function() {
        const tarefa = descTarefa.value.trim();
        if (tarefa) {
            addTaskToList(tarefa);
            modal.style.display = 'none';
            descTarefa.value = '';
            saveTasks();
        } else {
            alert('Descrição da tarefa não pode estar vazia.');
        }
    }

    loadTasks();
});