

// Funcao adcionar
function adicionarTarefa(){
    const mytasks  = document.getElementById('lista');


    // Declarando os Atributos
    let tarefa = document.getElementById("texto1").value;
    let novaTarefa = document.createElement("li");
    let checkbox = document.createElement("input")
    let remove = document.createElement("Button")
    let tex = document.createElement("label")


    // Colocando propriedades nos Atributos
    checkbox.type='checkbox';
    tex.textContent=document.getElementById("texto1").value;
    remove.type="button"
    remove.textContent ="Remover"
    tex.className="task_tex";
    remove.className="bnt";
    novaTarefa.className = "linha";

    
    // Add
    novaTarefa.appendChild(checkbox)
    novaTarefa.appendChild(tex)
    novaTarefa.appendChild(remove)            

    // Chamando o metodo completed ao clicar na novatarefa
    novaTarefa.onclick= function(){
        completed(this)
    }
   // Chamando o metodo remove ao clicar no butao remove
    remove.onclick= function(){
        //mytasks.removeChild(novaTarefa);
        novaTarefa.remove();
        removerTarefa(tarefa);
    }

    document.getElementById('lista').appendChild(novaTarefa);

    // Vamor colocar as tarefas no localStorage
    let tarefas = JSON.parse(localStorage.getItem('tarefas')) || [];
    tarefas.push(tarefa);
    localStorage.setItem('tarefas', JSON.stringify(tarefas));

   
    alert(tarefa + " adicionada");
    document.getElementById("texto1").value="";

}

// Funcao remover
function removerTarefa(tarefa) {
    let tarefas = JSON.parse(localStorage.getItem('tarefas')) || [];
    tarefas = tarefas.filter(t => t !== tarefa);
    localStorage.setItem('tarefas', JSON.stringify(tarefas));
}

//Marcar as tarefas completadas
function completed(element){
    element.classList.toggle("completed")
}


// Para carregar Tarefas 
document.addEventListener('DOMContentLoaded', carregarTarefas);
function carregarTarefas() {
    let tarefas = JSON.parse(localStorage.getItem('tarefas')) || [];
    tarefas.forEach(tarefa => {
        let novaTarefa = document.createElement("li");
        let checkbox = document.createElement("input");
        let remove = document.createElement("button");
        let tex = document.createElement("label");

        checkbox.type = 'checkbox';
        tex.textContent = tarefa;
        remove.type = "button";
        remove.textContent = "Remover";
        tex.className = "task_tex";
        remove.className = "bnt";

        novaTarefa.className = "linha";
        novaTarefa.appendChild(checkbox);
        novaTarefa.appendChild(tex);
        novaTarefa.appendChild(remove);

        document.getElementById('lista').appendChild(novaTarefa);

        // Verifica se a tarefa está marcada como completa
        if (tarefa.completed) {
            checkbox.checked = true;
            novaTarefa.classList.add('completed');
        }

        remove.addEventListener('click', function() {
            novaTarefa.remove();
            removerTarefa(tarefa);
        });

        checkbox.addEventListener('change', function() {
            if (checkbox.checked) {
                novaTarefa.classList.add('completed');
                tarefa.completed = true;

            } else {
                novaTarefa.classList.remove('completed');
                tarefa.completed = false;

            }
            atualizarTarefas(tarefas);
        });
    });
}

function atualizarTarefas(tarefas) {
    localStorage.setItem('tarefas', JSON.stringify(tarefas));
}
